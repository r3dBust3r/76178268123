# DO NOT FORGET TO TAKE A LOOK AT
---


- [ ] `malloc()`
- [ ] `structs`
- [ ] `putnbr_base`
- [ ] `atoi`
- [ ] `putnbr`
- [ ] `recursion`
