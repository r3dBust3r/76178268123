/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush02.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 17:38:29 by ottalhao          #+#    #+#             */
/*   Updated: 2025/07/20 17:38:30 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_rush(int w, int h, int i, int j)
{
	while (i < h)
	{
		j = 0;
		while (j < w)
		{
			if (j == 0 || j == w - 1 || i == 0 || i == h - 1)
			{
				if ((j == 0 && i == 0) || (j == 0 && i == h - 1))
					ft_putchar('A');
				else if ((j == w - 1 && i == 0) || (j == w - 1 && i == h - 1))
					ft_putchar('C');
				else
					ft_putchar('B');
			}
			else
				ft_putchar(' ');
			j++;
		}
		ft_putchar('\n');
		i++;
	}
}

void	rush(int x, int y)
{
	ft_rush(x, y, 0, 0);
}
