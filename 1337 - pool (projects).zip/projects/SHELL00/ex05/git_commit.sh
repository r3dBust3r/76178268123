git log | grep -E ^commit | head -n5 | sed 's/commit //g'
