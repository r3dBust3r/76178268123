/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <ottalhao@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/28 10:37:28 by ottalhao          #+#    #+#             */
/*   Updated: 2025/08/05 15:54:05 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	size;
	int	*ptr;
	int	i;

	if (min >= max)
	{
		ptr = NULL;
		return (ptr);
	}
	size = max - min;
	ptr = malloc(sizeof(int) * size);
	if (!ptr)
		return (NULL);
	i = 0;
	while (i < size)
	{
		ptr[i] = min + i;
		i++;
	}
	return (ptr);
}

// #include <stdio.h>
// int main(void)
// {
// 	int min = 12;
// 	int max = 19;
// 	int *arr = ft_range(min, max);

// 	int i = 0;
// 	while (i < (max - min))
// 	{
// 		printf("%d\n", arr[i]);
// 		i++;
// 	}
// 	return (0);
// }
