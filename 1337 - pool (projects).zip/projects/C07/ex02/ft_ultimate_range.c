/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <ottalhao@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 19:44:44 by ottalhao          #+#    #+#             */
/*   Updated: 2025/08/04 19:44:46 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	size;
	int	*arr;
	int	i;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	size = max - min;
	arr = malloc(sizeof(int) * size);
	if (! arr)
	{
		*range = NULL;
		return (-1);
	}
	i = 0;
	while (i < size)
	{
		arr[i] = min + i;
		i++;
	}
	*range = arr;
	return (size);
}

// #include <stdio.h>
// int main()
// {
//     int *int_arr;
//     int size = ft_ultimate_range(&int_arr, 50, 63);

//     if (size > 0)
//     {
// 		int i = 0;
// 		while (i < size)
// 		{
// 			printf("%d\n", int_arr[i]);
// 			i++;
// 		}
//     }
//     return (0);
// }