/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <ottalhao@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/05 10:20:37 by ottalhao          #+#    #+#             */
/*   Updated: 2025/08/05 10:20:39 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	get_sep_len(int size, char sep[])
{
	return (ft_strlen(sep) * (size - 1));
}

int	calc_alloc_size(int size, char **strs, char *sep)
{
	int	alloc_size;
	int	i;
	int	j;

	alloc_size = 0;
	i = 0;
	while (i < size)
	{
		j = 0;
		while (strs[i][j])
		{
			alloc_size++;
			j++;
		}
		i++;
	}
	return (alloc_size + get_sep_len(size, sep) + 1);
}

void	copy_to_alloc(int size, char **strs, char *concat_str, char *sep)
{
	int	str_index;
	int	sep_index;
	int	i;
	int	j;

	sep_index = 0;
	str_index = 0;
	i = 0;
	while (i < size)
	{
		j = 0;
		while (strs[i][j])
			concat_str[str_index++] = strs[i][j++];
		if (i == size - 1)
			break ;
		sep_index = 0;
		while (sep[sep_index])
			concat_str[str_index++] = sep[sep_index++];
		i++;
	}
	concat_str[str_index] = '\0';
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*concat_str;

	if (size == 0)
	{
		concat_str = malloc(sizeof(char));
		concat_str[0] = '\0';
		return (concat_str);
	}
	concat_str = malloc(sizeof(char) * calc_alloc_size(size, strs, sep));
	copy_to_alloc(size, strs, concat_str, sep);
	return (concat_str);
}

// #include <stdio.h>
// int	main(void)
// {
// 	int size;
// 	char	*strs[] = {"I", "can", "code", "in", "C", "lang!"};
// 	size = 6;
// 	char *conc_strs = ft_strjoin(size, strs, "...");
// 	printf("\n%s\n", conc_strs);
// 	return (0);
// }
