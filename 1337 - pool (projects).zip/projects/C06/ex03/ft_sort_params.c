/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <ottalhao@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/27 21:46:52 by ottalhao          #+#    #+#             */
/*   Updated: 2025/07/27 21:46:53 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char str[])
{
	int	i;

	i = 0;
	while (str[i])
	{
		i++;
	}
	return (i);
}

int	ft_strcmp(char *s1, char *s2)
{
	int	len;
	int	i;

	len = ft_strlen(s1);
	if (ft_strlen(s2) > ft_strlen(s1))
		len = ft_strlen(s2);
	i = 0;
	while (i < len)
	{
		if (s1[i] > s2[i])
			return (s1[i] - s2[i]);
		else if (s1[i] < s2[i])
			return ((s2[i] - s1[i]) * -1);
		i++;
	}
	if (ft_strlen(s1) > ft_strlen(s2))
		return (s1[i]);
	else if (ft_strlen(s2) > ft_strlen(s1))
		return (s2[i] * -1);
	return (0);
}

void	ft_putchar(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		write(1, &str[i++], 1);
	write(1, "\n", 1);
}

int	main(int argc, char *argv[])
{
	int		i;
	int		j;
	char	*temp;

	i = 1 ;
	while (i < argc - 1)
	{
		j = i + 1;
		while (j < argc)
		{
			if (ft_strcmp(argv[i], argv[j]) > 0)
			{
				temp = argv[i];
				argv[i] = argv[j];
				argv[j] = temp;
			}
			j++;
		}
		i++;
	}
	i = 1;
	while (i < argc)
		ft_putchar(argv[i++]);
}
