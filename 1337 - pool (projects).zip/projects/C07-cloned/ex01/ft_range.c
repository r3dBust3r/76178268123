/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mlakhlil <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 10:31:59 by mlakhlil          #+#    #+#             */
/*   Updated: 2025/08/04 12:02:14 by mlakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
// #include <stdio.h>
int	*ft_range(int min, int max)
{
	int	*ints_arr;
	int	*state;
	int	i;

	if (min >= max)
	{
		return (NULL);
	}
	ints_arr = (int *)malloc((max - min) * sizeof(int));
	if (ints_arr == NULL)
	{
		return (NULL);
	}
	state = ints_arr;
	i = min;
	while (i < max)
	{
		*ints_arr = i;
		i++;
		ints_arr++;
	}
	return (state);
}
/*
int	main()
{
	int *res;
	res = ft_range(5, 10);
	while (*res)
	{
		printf("%d\n", *res);
		res++;
	}
	return (0);
}*/
