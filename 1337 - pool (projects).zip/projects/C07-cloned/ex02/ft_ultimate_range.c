/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mlakhlil <mlakhlil@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 16:13:05 by mlakhlil          #+#    #+#             */
/*   Updated: 2025/08/04 12:09:02 by mlakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
// #include <stdio.h>
int	ft_ultimate_range(int **range, int min, int max)
{
	int	*ints_arr;
	int	*state;
	int	i;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	ints_arr = (int *)malloc((max - min) * sizeof(int));
	if (ints_arr == NULL)
	{
		return (-1);
	}
	state = ints_arr;
	i = min;
	while (i < max)
	{
		*ints_arr = i;
		i++;
		ints_arr++;
	}
	*range = state;
	return (max - min);
}
/*
int	main()
{
	int	res;
	int rge = 5;
	int *rge1 = 0;
	rge1 = &rge;
	res = ft_ultimate_range(&rge1, 5, 10);
	printf("result received : %d\n", res);
	while (*rge1)
	{
		printf("printed : %d\n", *rge1);
		rge1++;
	}
	return (0);
}*/
