/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mlakhlil <mlakhlil@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/03 17:01:06 by mlakhlil          #+#    #+#             */
/*   Updated: 2025/08/03 17:03:20 by mlakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
// #include <stdio.h>
int	ft_strlen(char *src)
{
	char	*src_al;
	int		count;

	count = 0;
	src_al = src;
	while (*src_al)
	{
		count++;
		src_al++;
	}
	return (count);
}

char	*ft_strdup(char *src)
{
	char	*dest;
	char	*state;

	dest = (char *)malloc(ft_strlen(src) + 1);
	if (dest == NULL)
	{
		return (NULL);
	}
	state = dest;
	while (*src)
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (state);
}
/*
int	main()
{
	char *res;
	res = ft_strdup("abcdef");
	printf("%s", res);
	return (0);
}*/
