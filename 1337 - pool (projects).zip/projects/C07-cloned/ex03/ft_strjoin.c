/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mlakhlil <mlakhlil@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 11:06:56 by mlakhlil          #+#    #+#             */
/*   Updated: 2025/08/04 11:37:25 by mlakhlil         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
// #include <stdio.h>
int	total_size(char **strs, int size)
{
	int	count;
	int	i;
	int	g;

	count = 0;
	g = 0;
	while (g < size)
	{
		i = 0;
		while (strs[g][i])
		{
			count++;
			i++;
		}
		g++;
	}
	return (count);
}

int	sepbyte_calc(char *sep, int size)
{
	int		count;
	char	*sep_tu;

	count = 0;
	sep_tu = sep;
	while (*sep_tu)
	{
		count++;
		sep_tu++;
	}
	return (count * (size - 1));
}

void	putin_str(int size, char **strs, char *sep, char *dest)
{
	int	i;
	int	g;
	int	is;

	g = 0;
	while (g < size)
	{
		i = 0;
		while (strs[g][i])
		{
			*dest = strs[g][i];
			i++;
			dest++;
		}
		is = 0;
		while (sep[is] && g < size - 1)
		{
			*dest = sep[is];
			is++;
			dest++;
		}
		g++;
	}
	*dest = '\0';
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*dest;
	char	*state;
	int		sepbyte;

	if (size == 0)
	{
		dest = (char *)malloc(1);
		*dest = '\0';
		return (dest);
	}
	sepbyte = sepbyte_calc(sep, size);
	dest = (char *)malloc((total_size(strs, size) + sepbyte) + 1);
	state = dest;
	putin_str(size, strs, sep, dest);
	return (state);
}
/*
int main(void)
{
    char    *strs[] = {"great", "world", "hello"};
    char    *separator = "+/-";

    char    *result;
    int     size = 3;

    result = ft_strjoin(size, strs, separator);
    if (result != NULL)
    {
        printf("%s\n", result);
        free(result);
    }
    return (0);
}*/
