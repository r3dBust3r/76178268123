int ft_fibonacci(int index)
{
	if (index == 0)
		return 0;
	
	if (index == 1)
		return 1;
	
	return (ft_fibonacci(index - 1) + ft_fibonacci(index - 2));
}


#include <stdio.h>
int main(void)
{
	int n = 1;
	while (n <= 30)
	{
		printf("fibonacci(%d) = %d\n", n, ft_fibonacci(n));
		n++;
	}
	return 0;
}