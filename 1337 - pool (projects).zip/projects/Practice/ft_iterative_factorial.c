int ft_iterative_factorial(int nb)
{
	int i = 1;
	unsigned long int f = 1;

	if (nb == 0)
		return 0;
	while (i <= nb)
	{
		f = f * i;
		i++;
	}
	return (f);
}

#include <stdio.h>

int main(void)
{
	// int n = 5;
	int i = 0;
	while (i <= 16)
	{
		printf("factorial of %d = %d\n", i, ft_iterative_factorial(i));
		i++;
	}
	return 0;
}
