void ft_swap(int *a, int *b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

#include <stdio.h>

int main(void)
{
	int x = 12;
	int y = 8;
	ft_swap(&x, &y);

	printf("x = %d\ny = %d", x, y);
}
