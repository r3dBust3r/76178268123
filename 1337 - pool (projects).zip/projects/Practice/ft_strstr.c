#include <stdio.h>

int is_located(char *str, char *needle, int index)
{
	int i = 0;
	while (needle[i])
	{
		if (str[index + i] != needle[i])
			return (0);
		i++;
	}
	return (1);
}

char *ft_strstr(char *str, char *to_find)
{
	int i = 0;

	if (to_find[0] == '\0')
		return (str);
	while (str[i])
	{
		if (str[i] == to_find[0])
		{
			if (is_located(str, to_find, i))
			{
				return (str + i);
			}
		}
		i++;
	}

	return (0);

}


int main(void)
{
	char str[] = "hello, I am a C lang programmer, I can create C built-in functions";
	char needle[] = "";

	printf("%s", ft_strstr(str, needle));

	return (0);
}