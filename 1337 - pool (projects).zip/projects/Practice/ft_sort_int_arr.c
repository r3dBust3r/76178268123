void ft_sort_int_arr(int *tab, int size)
{
	int i = 0;
	int j;
	int temp;

	while (i < size - 1)
	{
		j = i + 1;
		while (j < size)
		{
			if (tab[i] > tab[j])
			{
				temp = tab[i];
				tab[i] = tab[j];
				tab[j] = temp;
			}
			j++;
		}
		i++;
	}
}

#include <stdio.h>

int main(void)
{
	int arr[] = {123, 43, -839, 728, 0, -1, 8, 892, -66};
	int size = 9;
	ft_sort_int_arr(arr, size);

	int i = 0;
	printf("[");
	while (i < size)
	{
		printf("%d", arr[i]);
		if (i < size - 1) printf(", ");
		i++;
	}
	printf("]");

	return 0;
}