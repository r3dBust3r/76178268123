// int add_prime_sum(unsigned int n)
// {

// }

int atoi(char *str)
{
	int i = 0;
	int sign = 1;
	int r = 0;

	while ((str[i] == ' ' || str[i] == '\t' || str[i] == '\v' || str[i] == '\n'))
		i++;
	
	while (str[i] == '-' || str[i] == '+')
		if (str[i] == '-') sign = -sign;
	while (str[i] <= '9' && str[i] >= '0')
		r = r * 10 + (str[i++] - '0');

	return (r * sign);
}

int is_prime(int n)
{
	int i = 2;
	while(i < n)
	{
		if (n % i == 0) return 0;
		i++;
	}

	return 1;
}

#include <stdio.h>

int main(int argc, char *argv[])
{
	
	int sum = 0;

	if (argc != 2)
	{
		printf("0\n");
		return 0;
	}
	if (atoi(argv[1]) <= 0)
	{
		printf("0\n");
		return 0;
	}

	int i = 2;
	while (i <= atoi(argv[1]))
	{
		if (is_prime(i))
			sum += i;
		i++;
	}
	printf("%d", sum);
	return 0;
}