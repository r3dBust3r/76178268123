#include <stdio.h>
#include <unistd.h>

int is_space(char c)
{
	if (c == ' ' || c == '\t' || c == '\v')
		return 1;
	return 0;
}

int trailing_spaces_only(char *str, int index)
{
	while (str[index])
	{
		if (! is_space(str[index]))
		{
			return 0;
		}
		index++;
	}
	return 1;
}

int main(int argc, char *argv[])
{
	
	if (argc != 2)
	{
		printf("\n");
		return 0;
	}

	if (argv[1][0] == '\0')
	{
		printf("\n");
		return 0;
	}

	int i = 0;
	char *str = argv[1];
	while (str[i] == ' ' || str[i] == '\t')
		i++;

	int space_seq = 0;
	while (str[i])
	{
		if (is_space(str[i]))
		{
			if (space_seq == 0)
			{
				if (! trailing_spaces_only(str, i))
				{
					write(1, " ", 1);
				}
				space_seq = 1;
			}
		}
		else
		{
			write(1, &str[i], 1);
			space_seq = 0;
		}
		i++;
	}
	return 0;
}
