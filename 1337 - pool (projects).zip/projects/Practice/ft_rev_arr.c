void ft_rev_arr(int *tab, int size)
{
	int temp;
	int i = 0;

	while (i < (size / 2))
	{
		temp = tab[i];
		tab[i] = tab[size - i - 1];
		tab[size - i - 1] = temp;
		i++;
	}
}

#include <stdio.h>

int main(void)
{
	int arr[] = {1,2,3,4,5,6};
	int size = 6;
	ft_rev_arr(arr, size);

	int i = 0;
	printf("[");
	while (i < size)
	{
		printf("%d", arr[i]);
		if (i < size - 1) printf(", ");
		i++;
	}
	printf("]");

	return 0;
}