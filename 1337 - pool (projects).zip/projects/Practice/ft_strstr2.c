#include <stdio.h>

char *ft_strstr(char *str, char *to_find)
{
	int i = 0;
	int j;

	if (to_find[0] == '\0')
		return (str);
	while (str[i])
	{
		if (str[i] == to_find[0])
		{
			j = 0;
			while (to_find[j])
			{
				if (str[i + j] != to_find[j])
					return (0);
				j++;
			}
			return (str + i);
		}
		i++;
	}

	return (0);

}


int main(void)
{
	char str[] = "hello, I am a C lang programmer, I can create C built-in functions";
	char needle[] = "";

	printf("%s", ft_strstr(str, needle));

	return (0);
}