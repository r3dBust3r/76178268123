int ft_iterative_power(int nb, int power)
{
	int i = 1;
	int r = 1;
	while (i <= power)
	{
		r = r * nb;
		i++;
	}
	return (r);
}


#include <stdio.h>
int main(void)
{
	int nb = 4;
	int power = 5;
	printf("(%d) power of (%d) = %d\n", nb, power, ft_iterative_power(nb, power));
	return 0;
}

