#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int pgcd(int n)
{
	char hex[] = "0123456789abcdef";

	if (n < 16)
	{
		write(1, &hex[n], 1);
		return 0;
	}

	pgcd(n / 16);
	pgcd(n % 16);

	return 0;
}

int main(int argc, char *argv[])
{

	if (argc != 2) return 0;

	int n = atoi(argv[1]);

	if (n < 0)
	{
		printf("No plz no");
		return 0;
	}

	pgcd(n);

	return 0;
}
