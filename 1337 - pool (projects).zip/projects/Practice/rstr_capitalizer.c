#include <stdio.h>

int str_len(char *str)
{
	int i = 0;
	while (str[i]) i++;
	return i;
}

int main(int argc, char *argv[])
{
	if (argc == 1)
	{
		printf("No inputs!");
		return 0;
	}

	char c;

	int i = 1;
	while(i < argc)
	{
		int j = 0;
		while (j < str_len(argv[i]))
		{
			c = argv[i][j];
			if (c == ' ' || c == '\t') j++;
			if (j != 0 && argv[i])
			{
				// if (argv[i][j])
			}
			//  "hello "

			// printf("%c", argv[i][j]);
			j++;
		}
		i++;
	}
	return 0;
}
