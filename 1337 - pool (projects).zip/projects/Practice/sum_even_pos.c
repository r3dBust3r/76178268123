#include <stdio.h>

int sum_odd_pos(char *num)
{
	int i = 0;
	int sum = 0;
	char c;

	while(num[i])
	{
		c = num[i];
		if (c >= '0' && c <= '9')
			if (i % 2 == 0) sum += c - '0';
		i++;
	}

	return (sum);
}

int main(void)
{
	char x[] = "0123456789";
	printf("%d", sum_odd_pos(x));

	return (0);
}
