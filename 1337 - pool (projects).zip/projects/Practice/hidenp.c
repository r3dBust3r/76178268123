#include <stdio.h>

int main(int argc, char *argv[])
{
	if (argc != 3)
	{
		printf("\n");
		return 0;
	}

	char *needle = argv[1];
	char *str = argv[2];

	int i = 0;
	int j = 0;
	
	while(needle[i])
	{
		while(str[j] && str[j] != needle[i])
			j++;

		if (! str[j])
		{
			printf("0");
			return 0;
		}

		i++;
		j++;
	}

	printf("1");
	return 0;
}