#include <unistd.h>

void ft_putstr(char *str)
{
	int i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}


char *ft_strcat(char *dest, char *src)
{
	int i = 0;
	int j = 0;
	while (dest[i])
		i++;

	while (src[j])
	{
		dest[i + j] = src[j];
		j++;
	}
	dest[i + j] = '\0';

	return (dest);
}

int main(void)
{
	char source[] = ".World!";
	char dest[] = "Hello";
	
	ft_strcat(dest, source);
	ft_putstr(dest);
	return 0;
}