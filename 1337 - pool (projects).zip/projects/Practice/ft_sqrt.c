int ft_sqrt(int nb)
{
	int i = 1;
	while (i <= nb)
	{
		if (i * i == nb) return i;
		i++;
	}
	return 0;
}

#include <stdio.h>
int main(void)
{
	int sr;
	int n = 1;
	while (n <= 1000)
	{
		sr = ft_sqrt(n);
		if (sr != 0) printf("Square root of (%d) = %d\n", n, sr);
		n++;
	}
	return 0;
}