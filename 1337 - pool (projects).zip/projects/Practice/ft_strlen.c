int ft_strlen(char *str)
{
	int i = 0;
	while (str[i]) i++;
	return (i);
}

#include <stdio.h>

int main(void)
{
	printf("number of chars: %d", ft_strlen("hello world from C lang!"));
}