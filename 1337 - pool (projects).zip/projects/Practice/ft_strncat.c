#include <unistd.h>

void ft_putstr(char *str)
{
	int i = 0;
	while (str[i])
	{
		write(1, &str[i], 1);
		i++;
	}
}


char *ft_strncat(char *dest, char *src, unsigned int n)
{
	unsigned int i = 0;
	unsigned int j = 0;

	if (n == 0)
		return (dest);

	while (dest[i])
		i++;

	while (src[j] && j < n)
	{
		dest[i + j] = src[j];
		j++;
	}
	dest[i + j] = '\0';

	return (dest);
}

int main(void)
{
	char src[] = ".World!";
	char dst[] = "Hello";
	
	ft_strncat(dst, src, 3);
	ft_putstr(dst);
	return 0;
}