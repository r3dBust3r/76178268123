#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int     *ft_rrange(int start, int end)
{
	int num_of_elms = end - start + 1;
	
	int *ptr = malloc(num_of_elms * 4);

	int i = 0;
	while (i < num_of_elms)
	{
		*(ptr + i) = (end - i);
		i++;
	}

	return (ptr);
}


int main(void)
{
	int start = 10;
	int end   = 20;
	int size = end - start + 1;

	int *arr = ft_rrange(start, end);

	int i = 0;

	printf("[");

	while (i < size)
	{
		if (*(arr + i) != (end - start) / 2) printf("%d", *(arr + i));
		else printf("-- HALF --");
		if (i != size - 1) printf(", ");
		i++;
	}

	printf("]");

	return (0);
}

