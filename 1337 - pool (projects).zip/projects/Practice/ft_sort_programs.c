#include <stdio.h>

int ft_strlen(char *str)
{
	int i = 0;
	while (str[i])
		i++;
	return (i);
}

int ft_strcmp(char *s1, char *s2)
{
	int i = 0;
	while (s1[i] && s2[i])
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	if (ft_strlen(s1) != ft_strlen(s2))
		return (s1[i] - s2[i]);

	return (0);
}

int main(int argc, char *argv[])
{
	int i = 1;
	int j;
	char *temp;

	while (i < argc - 1)
	{
		j = i + 1;
		while (j < argc)
		{
			if (ft_strcmp(argv[i], argv[j]) > 0)
			{
				temp = argv[i];
				argv[i] = argv[j];
				argv[j] = temp;
			}
			j++;
		}
		i++;
	}

	i = 1;
	while (i < argc) printf("%s\n", argv[i++]);
}

/**
 * 
 
argc 	= 6
index 	= 1 -> 5

while (i <)

 */