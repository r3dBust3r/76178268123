#include <unistd.h>

int	ft_atoi(char *str)
{
	int	i;
	int	sign;
	int	res;

	i = 0;
	sign = 1;
	res = 0;
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n'
		|| str[i] == '\v' || str[i] == '\f' || str[i] == '\r')
		i++;
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			sign = -sign;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		res = res * 10 + (str[i] - '0');
		i++;
	}
	return (res * sign);
}


#include <stdio.h>

int main(void)
{
	printf("%d\n", ft_atoi("78172312"));
	printf("%d\n", ft_atoi("---234"));
	printf("%d\n", ft_atoi("--+72c6"));
	printf("%d\n", ft_atoi("--&82"));
	printf("%d\n", ft_atoi("&&"));
	printf("%d\n", ft_atoi("    -+23"));
	printf("%d\n", ft_atoi("    -+.23"));
	return 0;
}

     
