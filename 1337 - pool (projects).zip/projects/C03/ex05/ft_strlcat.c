/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <ottalhao@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/27 10:15:11 by ottalhao          #+#    #+#             */
/*   Updated: 2025/08/03 10:32:02 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	src_i;
	unsigned int	dst_i;
	unsigned int	i;

	src_i = 0;
	dst_i = 0;
	while (dst_i < size && dest[dst_i])
		dst_i++;
	while (src[src_i])
		src_i++;
	if (dst_i == size)
		return (size + src_i);
	i = 0;
	while (src[i] && (dst_i + i + 1) < size)
	{
		dest[dst_i + i] = src[i];
		i++;
	}
	if ((dst_i + i) < size)
		dest[dst_i + i] = '\0';
	return (dst_i + src_i);
}
