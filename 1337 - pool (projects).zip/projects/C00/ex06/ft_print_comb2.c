/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/18 06:19:03 by ottalhao          #+#    #+#             */
/*   Updated: 2025/08/03 11:46:30 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_comb2(void)
{
	char	buffer[7];
	int		a;
	int		b;

	a = 0;
	while (a < 99)
	{
		b = a + 1;
		while (b < 100)
		{
			buffer[0] = '0' + a / 10;
			buffer[1] = '0' + a % 10;
			buffer[2] = ' ';
			buffer[3] = '0' + b / 10;
			buffer[4] = '0' + b % 10;
			buffer[5] = ',';
			buffer[6] = ' ';
			if (a == 98 && b == 99)
				write(1, &buffer, 5);
			else
				write(1, &buffer, 7);
			b++;
		}
		a++;
	}
}
