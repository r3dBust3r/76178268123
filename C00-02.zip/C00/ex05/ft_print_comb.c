/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/17 14:26:35 by ottalhao          #+#    #+#             */
/*   Updated: 2025/07/17 17:21:55 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_prnt_char(char c)
{
	char	a;

	a = '0' + c;
	write(1, &a, 1);
}

void	ft_print_comb(void)
{
	char	a;
	char	b;
	char	c;

	a = 0;
	while (a <= 7)
	{
		b = a + 1;
		while (b <= 8)
		{
			c = b + 1;
			while (c <= 9)
			{
				ft_prnt_char(a);
				ft_prnt_char(b);
				ft_prnt_char(c);
				if (a == 7 && b == 8 && c == 9) {
                    break;
				}
				c++;
				write(1, ", ", 2);
			}
			b++;
		}
		a++;
	}
}
