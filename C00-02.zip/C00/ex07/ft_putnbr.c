/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ottalhao <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 14:30:06 by ottalhao          #+#    #+#             */
/*   Updated: 2025/07/20 14:30:37 by ottalhao         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_rev_str(char *str, int length) {
    int p = 0;
    char temp;
    while (p < length / 2) {
        temp = str[p];
        str[p] = str[length - 1 - p];
        str[length - 1 - p] = temp;
        p++;
    }
}

void ft_putnbr(int nb)
{
	if(nb < 0) 
	{
		write(1,"-",1);
		nb = -nb;
	}


	char str[20];
	int i=0;
	int a;
	int length = 0;


	while (nb > 0) {
		a = nb % 10;
		str[i] = a + '0';
		nb = nb / 10;
		i++;
		length++;
	}

	// ft_rev_str(str, length);
	
	int j=0;
	while (str[j] != '\0') {
		write(1, &str[j], 1);
		j++;
	}
}
